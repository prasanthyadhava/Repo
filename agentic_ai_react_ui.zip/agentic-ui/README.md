
# 🧠 Agentic AI Claims Triage UI

This React app lets users input a Claim ID and get a triage decision from an Agentic AI backend.

## 🚀 Live Backend API Endpoint

> https://repo-aidev.onrender.com/triage

## 🔧 How to Run

```bash
npm install
npm start
```

## 📦 Build for Production

```bash
npm run build
```

Built using React + fetch API + TailwindCSS-compatible structure.
